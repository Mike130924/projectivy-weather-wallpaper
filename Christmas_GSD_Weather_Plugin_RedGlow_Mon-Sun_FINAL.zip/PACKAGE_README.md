# Christmas GSD Weather Plugin 2.8.4 — source package

This archive contains the updated Android/Gradle source project and the original supplied Christmas GSD artwork. It preserves the existing Projectivy wallpaper-provider architecture and the complete settings categories. The Christmas weather card is centred, uses a contained burgundy-and-gold panel, leaves the wallpaper unchanged outside the card, and now receives all six forecast days after today (seven calendar days including today).

This ZIP is source only, not an APK. Import the source into `Mike130924/projectivy-weather-wallpaper` and let the repository's GitHub Actions build workflow compile it. The APK must then be installed and checked on the TV before the design is considered verified.
